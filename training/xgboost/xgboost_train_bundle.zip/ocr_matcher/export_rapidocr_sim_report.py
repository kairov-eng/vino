r"""
Выгрузка вин, у которых RapidOCR дал средний уровень совпадения с Gemini OCR.

Отбор: wines.label_ocr.ocr_rapidocr_onnx.compare.sim в диапазоне [--min-sim, --max-sim].
Для каждого вина в отчёт попадают тексты всех трёх каналов OCR этикетки:
Gemini (label_ocr.lines), RapidOCR (label_ocr.ocr_rapidocr_onnx.lines)
и Google Vision (label_ocr.ocr_google_vision.lines).

Запуск:
    python export_rapidocr_sim_report.py
    python export_rapidocr_sim_report.py --min-sim 0.3 --max-sim 0.6 --out ..\reports\rapidocr.xlsx
"""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter
from sqlalchemy import create_engine, text

from prepare_dataset import resolve_database_url

DEFAULT_ENV = Path(r"C:\dev\Vino2026\vino-svoe\backend\.env")
DEFAULT_OUT = Path(r"C:\dev\Vino2026\models\reports\rapidocr_sim_0.3_0.6.xlsx")
DEFAULT_BASE_URL = "http://127.0.0.1:8091/wines"

QUERY = text(
    """
    SELECT
        id,
        slug,
        name,
        winery,
        label_ocr->'lines'                                AS gemini_lines,
        label_ocr->'ocr_rapidocr_onnx'->'lines'           AS rapid_lines,
        label_ocr->'ocr_rapidocr_onnx'->'compare'->>'sim' AS rapid_sim,
        label_ocr->'ocr_google_vision'->'lines'           AS vision_lines,
        label_ocr->'ocr_google_vision'->'compare'->>'sim' AS vision_sim
    FROM wines
    WHERE label_ocr ? 'ocr_rapidocr_onnx'
      AND (label_ocr->'ocr_rapidocr_onnx'->'compare'->>'sim') ~ '^[0-9.]+$'
      AND (label_ocr->'ocr_rapidocr_onnx'->'compare'->>'sim')::float BETWEEN :min_sim AND :max_sim
    ORDER BY (label_ocr->'ocr_rapidocr_onnx'->'compare'->>'sim')::float
    """
)


def join_lines(value: object) -> str:
    if isinstance(value, list):
        return "\n".join(str(item) for item in value)
    if isinstance(value, str):
        return value
    return ""


def to_float(value: object) -> float | None:
    try:
        return round(float(value), 4)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None


def autoformat(path: Path) -> None:
    from openpyxl import load_workbook

    wb = load_workbook(path)
    ws = wb.active
    widths = {"A": 10, "B": 46, "C": 14, "D": 38, "E": 38, "F": 14, "G": 38}
    for column, width in widths.items():
        ws.column_dimensions[column].width = width
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    ws.auto_filter.ref = f"A1:{get_column_letter(ws.max_column)}{ws.max_row}"
    wb.save(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--min-sim", type=float, default=0.3)
    parser.add_argument("--max-sim", type=float, default=0.6)
    parser.add_argument("--env-file", type=Path, default=DEFAULT_ENV)
    parser.add_argument("--database-url", default=None)
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    engine = create_engine(resolve_database_url(args.database_url, args.env_file))
    with engine.connect() as conn:
        rows = conn.execute(
            QUERY, {"min_sim": args.min_sim, "max_sim": args.max_sim}
        ).mappings().all()

    records = []
    for row in rows:
        key = row["slug"] or row["id"]
        records.append(
            {
                "wine_id": row["id"],
                "url": f"{args.base_url}/{key}",
                "sim_rapid_ocr": to_float(row["rapid_sim"]),
                "lines_google_gemini": join_lines(row["gemini_lines"]),
                "lines_rapid_ocr": join_lines(row["rapid_lines"]),
                "sim_google_vision": to_float(row["vision_sim"]),
                "lines_google_vision": join_lines(row["vision_lines"]),
            }
        )

    frame = pd.DataFrame(records)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    frame.to_excel(args.out, index=False, sheet_name="rapidocr_sim")
    autoformat(args.out)

    csv_path = args.out.with_suffix(".csv")
    frame.to_csv(csv_path, index=False, encoding="utf-8-sig", sep=";")

    print(f"вин в диапазоне sim [{args.min_sim}; {args.max_sim}]: {len(frame)}")
    if not frame.empty:
        print(
            "sim_rapid_ocr: min=%.4f  median=%.4f  max=%.4f"
            % (
                frame.sim_rapid_ocr.min(),
                frame.sim_rapid_ocr.median(),
                frame.sim_rapid_ocr.max(),
            )
        )
        print(f"без текста Google Vision: {(frame.lines_google_vision == '').sum()}")
    print(f"xlsx: {args.out}")
    print(f"csv:  {csv_path}")


if __name__ == "__main__":
    main()
