"""Fine-tuning Cross-Encoder (Transformer) для OCR Text Matcher.

Вход:  models/data/processed/{train,validation,test}.jsonl  (text1 = OCR запроса, text2 = эталон вина, label 0/1)
Выход: models/cross_encoder_text_matcher/
         config.json, model.safetensors, tokenizer.*  — модель (CrossEncoder.load / save_pretrained)
         metrics.json          — ROC-AUC / F1 / Top-k / hard-negatives / latency (+ zero-shot и сравнение с XGBoost)
         train_config.json     — гиперпараметры
         predictions_test.csv  — вероятности на test

Базовая модель по умолчанию — multilingual MiniLM cross-encoder (XLM-R токенизатор, ru/en/fr/it/es/de):
    cross-encoder/mmarco-mMiniLMv2-L12-H384-v1      (~118M, точнее)
Быстрее / меньше:
    nreimers/mMiniLMv2-L6-H384-distilled-from-XLMR-Large

Loss: BinaryCrossEntropy на логитах (num_labels=1), на выходе predict — sigmoid → P(same wine).

Запуск:
    cd C:\\dev\\Vino2026\\models\\ocr_matcher
    python train_cross_encoder.py                        # CPU: ~45-60 мин (neg-per-pos 8, max_length 160, 3 эпохи)
    python train_cross_encoder.py --neg-per-pos 0 --epochs 4 --max-length 256   # все пары (GPU или долго на CPU)
    python train_cross_encoder.py --model nreimers/mMiniLMv2-L6-H384-distilled-from-XLMR-Large   # в 2 раза быстрее
    python train_cross_encoder.py --eval-only            # только оценка сохранённой модели
    # продолжить прерванное обучение с последнего чекпоинта (нужен --keep-checkpoints / прерванный run):
    python train_cross_encoder.py --resume-from-checkpoint last --epochs 3
    python train_cross_encoder.py --resume-from-checkpoint ..\\cross_encoder_text_matcher\\checkpoints\\checkpoint-128 --epochs 4
"""
from __future__ import annotations

import argparse
import json
import random
import shutil
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from eval_utils import (  # noqa: E402
    best_f1_threshold,
    classification_metrics,
    hard_negative_report,
    measure_latency_ms,
    print_metrics_table,
    topk_accuracy,
)

HERE = Path(__file__).resolve().parent
MODELS_DIR = HERE.parent
DEFAULT_DATA_DIR = MODELS_DIR / "data"
DEFAULT_OUT_DIR = MODELS_DIR / "cross_encoder_text_matcher"
DEFAULT_XGB_PRED = MODELS_DIR / "xgboost_text_matcher" / "predictions_test.csv"
DEFAULT_MODEL = "cross-encoder/mmarco-mMiniLMv2-L12-H384-v1"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    p.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    p.add_argument("--model", default=DEFAULT_MODEL, help="HF id базовой модели или локальный путь")
    p.add_argument("--epochs", type=float, default=3.0)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--lr", type=float, default=2e-5)
    p.add_argument("--warmup-ratio", type=float, default=0.1)
    p.add_argument("--weight-decay", type=float, default=0.01)
    p.add_argument("--max-length", type=int, default=160,
                   help="токенов на пару; 160 покрывает ~80%% пар целиком (p50=116, p90=197), режется хвост этикетки")
    p.add_argument("--neg-per-pos", type=int, default=8,
                   help="сколько обычных negatives на 1 positive оставить в train (0 = все 19). "
                        "Hard negatives (FP) остаются всегда. 8 → ~2000 пар, ~45 мин на CPU; 0 → ~4500 пар")
    p.add_argument("--pos-weight", default="none", help="'none' | 'auto' (neg/pos) | число — вес positives в BCE")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default=None, help="cpu | cuda (по умолчанию авто)")
    p.add_argument("--eval-only", action="store_true", help="не обучать; оценить модель из --out-dir")
    p.add_argument("--no-zero-shot", action="store_true", help="пропустить оценку базовой модели до обучения")
    p.add_argument("--keep-checkpoints", action="store_true", help="не удалять out-dir/checkpoints после обучения")
    p.add_argument("--resume-from-checkpoint", default=None,
                   help="продолжить обучение: путь к out-dir/checkpoints/checkpoint-N или 'last' (последний). "
                        "Восстанавливаются веса, optimizer, scheduler и RNG; --epochs = итоговое число эпох")
    p.add_argument("--save-total-limit", type=int, default=1,
                   help="сколько чекпоинтов хранить (по одному на эпоху); 0 = все")
    p.add_argument("--xgb-predictions", type=Path, default=DEFAULT_XGB_PRED,
                   help="predictions_test.csv от train_xgboost.py для сравнения / комбинации")
    p.add_argument("--xgb-top-k", type=int, default=3, help="Cross-Encoder переранжирует Top-k XGBoost")
    p.add_argument("--limit", type=int, default=None, help="ограничить train (отладка)")
    return p.parse_args()


def read_jsonl(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise SystemExit(f"Нет файла {path} — сначала запустите prepare_dataset.py")
    return pd.read_json(path, lines=True)


def subsample_negatives(df: pd.DataFrame, neg_per_pos: int, seed: int) -> pd.DataFrame:
    """Внутри каждого скана оставляем все positives / hard negatives и не более neg_per_pos обычных negatives."""
    if neg_per_pos <= 0:
        return df
    rnd = random.Random(seed)
    keep_idx: list[int] = []
    for _, grp in df.groupby("scan_id"):
        pos = grp[grp["label"] == 1]
        hard = grp[(grp["label"] == 0) & (grp["label_kind"] != "tn")]
        neg = grp[(grp["label"] == 0) & (grp["label_kind"] == "tn")]
        n_keep = max(1, len(pos)) * neg_per_pos
        neg_idx = list(neg.index)
        rnd.shuffle(neg_idx)
        keep_idx.extend(pos.index.tolist())
        keep_idx.extend(hard.index.tolist())
        keep_idx.extend(neg_idx[:n_keep])
    return df.loc[sorted(keep_idx)].reset_index(drop=True)


def predict_probs(model, df: pd.DataFrame, batch_size: int = 64) -> np.ndarray:
    pairs = list(zip(df["text1"].astype(str).tolist(), df["text2"].astype(str).tolist()))
    scores = model.predict(pairs, batch_size=batch_size, show_progress_bar=False, convert_to_numpy=True)
    return np.asarray(scores, dtype=float).reshape(-1)


def evaluate(df: pd.DataFrame, prob: np.ndarray, threshold: float) -> dict:
    y = df["label"].to_numpy(dtype=int)
    m = classification_metrics(y, prob, threshold)
    m.update(topk_accuracy(df["scan_id"].tolist(), y, prob))
    cos = df["siglip_cosine"].fillna(-1).to_numpy()
    base = topk_accuracy(df["scan_id"].tolist(), y, cos)
    m["baseline_cosine_top1_acc"] = base["top1_acc"]
    m["baseline_cosine_top3_acc"] = base["top3_acc"]
    m["hard_negatives"] = hard_negative_report(df["label_kind"].tolist(), prob, threshold)
    return m


def combine_with_xgboost(test: pd.DataFrame, ce_prob: np.ndarray, xgb_path: Path, top_k: int) -> dict | None:
    """Сравнение XGBoost / CE / XGBoost→Top-k→CE / среднее на одинаковых test-парах."""
    if not xgb_path.exists():
        return None
    xgb = pd.read_csv(xgb_path)[["scan_id", "wine_id", "prob"]].rename(columns={"prob": "xgb_prob"})
    df = test[["scan_id", "wine_id", "label"]].copy()
    df["ce_prob"] = ce_prob
    df = df.merge(xgb, on=["scan_id", "wine_id"], how="inner")
    if df.empty:
        return None
    y = df["label"].to_numpy(dtype=int)
    sids = df["scan_id"].tolist()
    out: dict[str, dict] = {
        "xgboost": topk_accuracy(sids, y, df["xgb_prob"].to_numpy()),
        "cross_encoder": topk_accuracy(sids, y, df["ce_prob"].to_numpy()),
        "mean_prob": topk_accuracy(sids, y, ((df["xgb_prob"] + df["ce_prob"]) / 2).to_numpy()),
    }
    out["xgboost"]["roc_auc"] = classification_metrics(y, df["xgb_prob"].to_numpy())["roc_auc"]
    out["cross_encoder"]["roc_auc"] = classification_metrics(y, df["ce_prob"].to_numpy())["roc_auc"]
    out["mean_prob"]["roc_auc"] = classification_metrics(y, ((df["xgb_prob"] + df["ce_prob"]) / 2).to_numpy())["roc_auc"]
    # XGBoost Top-k → CE выбирает финал: score = xgb_prob вне top-k, CE + 10 внутри top-k
    rerank = np.zeros(len(df))
    by_scan: dict = defaultdict(list)
    for i, (s, xp, cp) in enumerate(zip(sids, df["xgb_prob"], df["ce_prob"])):
        by_scan[s].append((i, xp, cp))
    for s, items in by_scan.items():
        items.sort(key=lambda t: -t[1])
        for rank, (i, xp, cp) in enumerate(items):
            rerank[i] = (10.0 + cp) if rank < top_k else xp
    out[f"xgboost_top{top_k}_then_ce"] = topk_accuracy(sids, y, rerank)
    out["_pairs_compared"] = float(len(df))
    return out


def main() -> None:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = args.device or ("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device={device}  torch={torch.__version__}")

    from sentence_transformers.cross_encoder import CrossEncoder

    train = read_jsonl(args.data_dir / "processed" / "train.jsonl")
    valid = read_jsonl(args.data_dir / "processed" / "validation.jsonl")
    test = read_jsonl(args.data_dir / "processed" / "test.jsonl")
    print(f"pairs: train={len(train)} val={len(valid)} test={len(test)}")

    out = args.out_dir
    out.mkdir(parents=True, exist_ok=True)
    metrics: dict = {
        "created_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "base_model": args.model,
        "device": device,
    }

    if args.eval_only:
        model = CrossEncoder(str(out), num_labels=1, max_length=args.max_length,
                             device=device, activation_fn=torch.nn.Sigmoid())
        print(f"Загружена модель из {out}")
    else:
        ckpt_dir = out / "checkpoints"
        resume_path: str | None = None
        if args.resume_from_checkpoint:
            if str(args.resume_from_checkpoint).lower() == "last":
                from transformers.trainer_utils import get_last_checkpoint

                resume_path = get_last_checkpoint(str(ckpt_dir)) if ckpt_dir.exists() else None
                if resume_path is None:
                    raise SystemExit(f"В {ckpt_dir} нет чекпоинтов для --resume-from-checkpoint last")
            else:
                resume_path = str(Path(args.resume_from_checkpoint).resolve())
                if not Path(resume_path).exists():
                    raise SystemExit(f"Чекпоинт не найден: {resume_path}")
            print(f"Продолжаем обучение с чекпоинта: {resume_path}")

        model = CrossEncoder(args.model, num_labels=1, max_length=args.max_length,
                             device=device, activation_fn=torch.nn.Sigmoid())
        n_params = sum(p.numel() for p in model.model.parameters()) / 1e6
        print(f"Базовая модель {args.model}: {n_params:.1f}M параметров, max_length={args.max_length}")

        if not args.no_zero_shot and resume_path is None:
            t0 = time.perf_counter()
            p0 = predict_probs(model, test)
            metrics["zero_shot_test"] = evaluate(test, p0, 0.5)
            print(f"zero-shot test: ROC-AUC={metrics['zero_shot_test'].get('roc_auc', float('nan')):.4f} "
                  f"Top-1={metrics['zero_shot_test']['top1_acc']:.4f} ({time.perf_counter() - t0:.0f}s)")

        train_df = subsample_negatives(train, args.neg_per_pos, args.seed)
        if args.limit:
            train_df = train_df.head(args.limit)
        n_pos, n_neg = int((train_df["label"] == 1).sum()), int((train_df["label"] == 0).sum())
        print(f"train после subsample: {len(train_df)} пар (pos={n_pos}, neg={n_neg})")

        from datasets import Dataset
        from sentence_transformers.cross_encoder import CrossEncoderTrainer, CrossEncoderTrainingArguments
        from sentence_transformers.cross_encoder.losses import BinaryCrossEntropyLoss

        def to_ds(df: pd.DataFrame) -> Dataset:
            return Dataset.from_dict({
                "text1": df["text1"].astype(str).tolist(),
                "text2": df["text2"].astype(str).tolist(),
                "label": df["label"].astype(float).tolist(),
            })

        pos_weight = None
        if str(args.pos_weight).lower() == "auto":
            pos_weight = torch.tensor(n_neg / max(1, n_pos))
        elif str(args.pos_weight).lower() != "none":
            pos_weight = torch.tensor(float(args.pos_weight))
        loss = BinaryCrossEntropyLoss(model, pos_weight=pos_weight)

        targs = CrossEncoderTrainingArguments(
            output_dir=str(ckpt_dir),
            num_train_epochs=args.epochs,
            per_device_train_batch_size=args.batch_size,
            per_device_eval_batch_size=max(32, args.batch_size),
            learning_rate=args.lr,
            warmup_ratio=args.warmup_ratio,
            weight_decay=args.weight_decay,
            eval_strategy="epoch",
            save_strategy="epoch",
            save_total_limit=(args.save_total_limit or None),
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            logging_steps=50,
            seed=args.seed,
            fp16=False,
            bf16=False,
            dataloader_num_workers=0,
            report_to="none",
            use_cpu=(device == "cpu"),
        )
        trainer = CrossEncoderTrainer(
            model=model,
            args=targs,
            train_dataset=to_ds(train_df),
            eval_dataset=to_ds(valid),
            loss=loss,
        )
        t0 = time.perf_counter()
        trainer.train(resume_from_checkpoint=resume_path)
        train_sec = time.perf_counter() - t0
        print(f"Обучение завершено за {train_sec / 60:.1f} мин")
        metrics["train_seconds"] = train_sec
        metrics["train_pairs"] = len(train_df)

        model.save_pretrained(str(out))
        if not args.keep_checkpoints and ckpt_dir.exists():
            shutil.rmtree(ckpt_dir, ignore_errors=True)
        cfg = {k: (str(v) if isinstance(v, Path) else v) for k, v in vars(args).items()}
        cfg["sentence_transformers_version"] = __import__("sentence_transformers").__version__
        cfg["pos_weight_effective"] = float(pos_weight) if pos_weight is not None else None
        (out / "train_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    # --- оценка ---
    p_va = predict_probs(model, valid)
    p_te = predict_probs(model, test)
    thr, f1_va = best_f1_threshold(valid["label"].to_numpy(dtype=int), p_va)
    print(f"best F1 threshold (validation) = {thr:.2f}  F1={f1_va:.4f}")
    metrics["threshold_best_f1_validation"] = thr
    metrics["validation"] = evaluate(valid, p_va, thr)
    metrics["test"] = evaluate(test, p_te, thr)
    metrics["test_at_0_5"] = classification_metrics(test["label"].to_numpy(dtype=int), p_te, 0.5)

    # --- latency (batch inference) ---
    sample = test[test["scan_id"] == test["scan_id"].iloc[0]]
    pairs20 = list(zip(sample["text1"].astype(str), sample["text2"].astype(str)))[:20]
    pairs5 = pairs20[:5]
    lat = {
        "device": device,
        "20_candidates": measure_latency_ms(lambda: model.predict(pairs20, batch_size=32, show_progress_bar=False), repeats=10),
        "5_candidates": measure_latency_ms(lambda: model.predict(pairs5, batch_size=32, show_progress_bar=False), repeats=10),
    }
    metrics["latency"] = lat

    # --- сравнение с XGBoost ---
    cmp = combine_with_xgboost(test, p_te, args.xgb_predictions, args.xgb_top_k)
    if cmp is not None:
        metrics["comparison_test"] = cmp

    # --- вывод ---
    blocks = {}
    if "zero_shot_test" in metrics:
        blocks["zero-shot test"] = metrics["zero_shot_test"]
    blocks["validation"] = metrics["validation"]
    blocks["test"] = metrics["test"]
    print_metrics_table(
        "Cross-Encoder — классификация",
        {k: {kk: vv for kk, vv in v.items() if kk in ("roc_auc", "pr_auc", "precision", "recall", "f1", "fpr")} for k, v in blocks.items()},
    )
    print_metrics_table(
        "Cross-Encoder — ранжирование по скану vs baseline SigLIP cosine",
        {k: {kk: vv for kk, vv in v.items() if kk in ("top1_acc", "top3_acc", "top5_acc", "mrr", "baseline_cosine_top1_acc", "scans_with_positive")} for k, v in blocks.items()},
    )
    print("\nHard negatives (FP-разметка) на test:", json.dumps(metrics["test"]["hard_negatives"].get("fp_hard"), ensure_ascii=False))
    if cmp is not None:
        print_metrics_table(
            f"Сравнение на test (одинаковые пары): XGBoost / CE / XGBoost Top-{args.xgb_top_k} → CE",
            {k: v for k, v in cmp.items() if not k.startswith("_")},
        )
    print(f"\nLatency ({device}): 20 кандидатов = {lat['20_candidates']['median_ms']:.0f} ms; "
          f"5 кандидатов = {lat['5_candidates']['median_ms']:.0f} ms")

    (out / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    pred = test[["scan_id", "wine_id", "group_id", "label", "label_kind", "siglip_cosine"]].copy()
    pred["prob"] = p_te
    pred.sort_values(["scan_id", "prob"], ascending=[True, False]).to_csv(out / "predictions_test.csv", index=False)
    print(f"Модель и метрики: {out}")


if __name__ == "__main__":
    main()
